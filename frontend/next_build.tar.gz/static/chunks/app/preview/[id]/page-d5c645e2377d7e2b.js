(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[297],{2237:function(t,e,a){Promise.resolve().then(a.bind(a,9161))},9161:function(t,e,a){"use strict";a.r(e),a.d(e,{default:function(){return g}});var r=a(7437),o=a(2265),n=a(6463),l=a(6264),i=a(9271),s=a(6277),c=a(3274),d=a(9451),h=a(2468),u=a(6884),p=a(7164),m=a(8030);/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let f=(0,m.Z)("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]),x=(0,m.Z)("ChevronUp",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);var y=a(3429);function g(){let t=(0,n.useParams)(),e=(0,n.useRouter)(),a=null==t?void 0:t.id,{user:m}=(0,y.a)(),[g,k]=(0,o.useState)(null),[v,b]=(0,o.useState)(!0),[w,N]=(0,o.useState)(null),[S,j]=(0,o.useState)(!1),[Z,M]=(0,o.useState)(!1),[_,C]=(0,o.useState)(!1);return((0,o.useEffect)(()=>{a&&l.s.getPortfolio(a).then(t=>{k(t),b(!1);{let e=i.V.getSavedPortfolios(null==m?void 0:m.id),r=localStorage.getItem("portfolio_".concat(a)),o=e.some(t=>t.id===a)||!!r,n=!!(m&&t.user_id&&Number(t.user_id)===Number(m.id));M(o||n)}}).catch(t=>{console.error(t),N("Portfolio not found or unavailable"),b(!1)})},[a,m]),v)?(0,r.jsxs)("div",{className:"min-h-screen bg-[#030712] flex flex-col items-center justify-center text-white space-y-4",children:[(0,r.jsx)(c.Z,{className:"w-10 h-10 animate-spin text-indigo-500"}),(0,r.jsx)("p",{className:"text-sm text-slate-400",children:"Loading Portfolio..."})]}):w||!g?(0,r.jsxs)("div",{className:"min-h-screen bg-[#030712] flex flex-col items-center justify-center text-white space-y-4 text-center p-4",children:[(0,r.jsx)("h2",{className:"text-2xl font-bold",children:"Portfolio Not Found"}),(0,r.jsx)("p",{className:"text-sm text-slate-400",children:"The requested portfolio link might have expired or been removed."}),(0,r.jsx)("a",{href:"/",className:"btn-primary text-xs py-2 px-4",children:"Create Portfolio"})]}):(0,r.jsxs)("div",{className:"min-h-screen bg-[#030712] relative",children:[(0,r.jsxs)("div",{className:"fixed top-4 right-4 z-50 flex items-center gap-2 p-2 rounded-2xl transition-all duration-300 shadow-2xl",style:{background:"rgba(10,15,30,0.85)",backdropFilter:"blur(20px)",border:"1px solid rgba(255,255,255,0.1)"},children:[!_&&(0,r.jsxs)(r.Fragment,{children:[Z&&(0,r.jsxs)("button",{type:"button",onClick:()=>{g&&(i.V.saveDraftData(g.data),i.V.saveDraftTheme(g.theme),e.push("/generate?step=3&theme=".concat(g.theme)))},className:"btn-primary text-xs py-1.5 px-3 bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-1.5",title:"Owner Control: Edit this portfolio",children:[(0,r.jsx)(d.Z,{className:"w-3.5 h-3.5"})," Edit Portfolio"]}),(0,r.jsxs)("button",{type:"button",onClick:()=>{navigator.clipboard.writeText(window.location.href),j(!0),setTimeout(()=>j(!1),2e3)},className:"btn-secondary text-xs py-1.5 px-3",title:"Share portfolio link",children:[S?(0,r.jsx)(h.Z,{className:"w-3.5 h-3.5 text-emerald-400"}):(0,r.jsx)(u.Z,{className:"w-3.5 h-3.5"}),S?"Copied":"Share"]}),(0,r.jsxs)("button",{type:"button",onClick:()=>{if(!g)return;let t=new Blob(['<!DOCTYPE html>\n<html lang="en" class="dark">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>'.concat(g.data.name,' — Recruiter Portfolio</title>\n  <script src="https://cdn.tailwindcss.com"></script>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">\n</head>\n<body class="bg-[#030712] text-slate-100 p-8">\n  <div class="max-w-4xl mx-auto space-y-8">\n    <h1 class="text-5xl font-extrabold text-white">').concat(g.data.name,'</h1>\n    <p class="text-xl text-indigo-400 font-semibold">').concat(g.data.title,'</p>\n    <p class="text-sm text-slate-300">').concat(g.data.about,"</p>\n  </div>\n</body>\n</html>")],{type:"text/html"}),e=URL.createObjectURL(t),a=document.createElement("a");a.href=e,a.download="".concat(g.data.name.replace(/\s+/g,"_"),"_Portfolio.html"),document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(e)},className:"btn-secondary text-xs py-1.5 px-3",title:"Download standalone HTML file",children:[(0,r.jsx)(p.Z,{className:"w-3.5 h-3.5"})," HTML"]})]}),(0,r.jsx)("button",{type:"button",onClick:()=>C(!_),className:"p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors",title:_?"Expand toolbar":"Minimize toolbar",children:_?(0,r.jsx)(f,{className:"w-4 h-4"}):(0,r.jsx)(x,{className:"w-4 h-4"})})]}),(0,r.jsx)(s.X,{data:g.data,theme:g.theme})]})}},9271:function(t,e,a){"use strict";a.d(e,{V:function(){return l}});let r="portfolioai_draft_data",o="portfolioai_draft_theme",n="portfolioai_saved_list",l={getDraftData(){try{let t=localStorage.getItem(r);return t?JSON.parse(t):null}catch(t){return null}},saveDraftData(t){try{localStorage.setItem(r,JSON.stringify(t))}catch(t){console.error("Error saving draft data",t)}},clearDraft(){try{localStorage.removeItem(r),localStorage.removeItem(o)}catch(t){console.error("Error clearing draft data",t)}},getDraftTheme(){try{return localStorage.getItem(o)||"modern-glass"}catch(t){return"modern-glass"}},saveDraftTheme(t){try{localStorage.setItem(o,t)}catch(t){console.error("Error saving draft theme",t)}},savePortfolioToHistory(t,e){try{let a=e?"".concat(n,"_").concat(e):n,r=localStorage.getItem(a),o=r?JSON.parse(r):[],l=o.findIndex(e=>e.id===t.id);l>=0?o[l]=t:o.unshift(t),localStorage.setItem(a,JSON.stringify(o)),localStorage.setItem("portfolio_".concat(t.id),JSON.stringify(t))}catch(t){console.error("Error saving portfolio to history",t)}},getSavedPortfolios(t){try{let e=t?"".concat(n,"_").concat(t):n,a=localStorage.getItem(e);return a?JSON.parse(a):[]}catch(t){return[]}},deleteSavedPortfolio(t,e){try{let a=e?"".concat(n,"_").concat(e):n,r=localStorage.getItem(a);if(r){let e=JSON.parse(r).filter(e=>e.id!==t);localStorage.setItem(a,JSON.stringify(e))}localStorage.removeItem("portfolio_".concat(t))}catch(t){console.error("Error deleting portfolio from history",t)}}}},5912:function(t,e,a){"use strict";a.d(e,{Z:function(){return r}});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(8030).Z)("Briefcase",[["path",{d:"M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16",key:"jecpp"}],["rect",{width:"20",height:"14",x:"2",y:"6",rx:"2",key:"i6l2r4"}]])},2468:function(t,e,a){"use strict";a.d(e,{Z:function(){return r}});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(8030).Z)("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]])},7419:function(t,e,a){"use strict";a.d(e,{Z:function(){return r}});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(8030).Z)("CodeXml",[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]])},6884:function(t,e,a){"use strict";a.d(e,{Z:function(){return r}});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(8030).Z)("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]])},5353:function(t,e,a){"use strict";a.d(e,{Z:function(){return r}});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(8030).Z)("Cpu",[["rect",{width:"16",height:"16",x:"4",y:"4",rx:"2",key:"14l7u7"}],["rect",{width:"6",height:"6",x:"9",y:"9",rx:"1",key:"5aljv4"}],["path",{d:"M15 2v2",key:"13l42r"}],["path",{d:"M15 20v2",key:"15mkzm"}],["path",{d:"M2 15h2",key:"1gxd5l"}],["path",{d:"M2 9h2",key:"1bbxkp"}],["path",{d:"M20 15h2",key:"19e6y8"}],["path",{d:"M20 9h2",key:"19tzq7"}],["path",{d:"M9 2v2",key:"165o2o"}],["path",{d:"M9 20v2",key:"i2bqo8"}]])},7164:function(t,e,a){"use strict";a.d(e,{Z:function(){return r}});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(8030).Z)("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]])},3787:function(t,e,a){"use strict";a.d(e,{Z:function(){return r}});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(8030).Z)("ExternalLink",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]])},4512:function(t,e,a){"use strict";a.d(e,{Z:function(){return r}});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(8030).Z)("FolderGit2",[["path",{d:"M9 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v5",key:"1w6njk"}],["circle",{cx:"13",cy:"12",r:"2",key:"1j92g6"}],["path",{d:"M18 19c-2.8 0-5-2.2-5-5v8",key:"pkpw2h"}],["circle",{cx:"20",cy:"19",r:"2",key:"1obnsp"}]])},3274:function(t,e,a){"use strict";a.d(e,{Z:function(){return r}});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(8030).Z)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},9451:function(t,e,a){"use strict";a.d(e,{Z:function(){return r}});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(8030).Z)("PenLine",[["path",{d:"M12 20h9",key:"t2du7b"}],["path",{d:"M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z",key:"1ykcvy"}]])}},function(t){t.O(0,[557,429,277,971,23,744],function(){return t(t.s=2237)}),_N_E=t.O()}]);