(()=>{var e={};e.id=297,e.ids=[297],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},2137:(e,t,a)=>{"use strict";a.r(t),a.d(t,{GlobalError:()=>o.a,__next_app__:()=>h,originalPathname:()=>p,pages:()=>c,routeModule:()=>x,tree:()=>d}),a(4185),a(9548),a(5866);var r=a(3191),s=a(8716),i=a(7922),o=a.n(i),l=a(5231),n={};for(let e in l)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(n[e]=()=>l[e]);a.d(t,n);let d=["",{children:["preview",{children:["[id]",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,4185)),"C:\\Users\\dream\\OneDrive\\Desktop\\PortfoliaAI\\frontend\\app\\preview\\[id]\\page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(a.bind(a,9548)),"C:\\Users\\dream\\OneDrive\\Desktop\\PortfoliaAI\\frontend\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,5866,23)),"next/dist/client/components/not-found-error"]}],c=["C:\\Users\\dream\\OneDrive\\Desktop\\PortfoliaAI\\frontend\\app\\preview\\[id]\\page.tsx"],p="/preview/[id]/page",h={require:a,loadChunk:()=>Promise.resolve()},x=new r.AppPageRouteModule({definition:{kind:s.x.APP_PAGE,page:"/preview/[id]/page",pathname:"/preview/[id]",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},3727:(e,t,a)=>{Promise.resolve().then(a.bind(a,2543))},2543:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>v});var r=a(326),s=a(7577),i=a(5047);a(6824);var o=a(3402),l=a(8773),n=a(7506),d=a(2685),c=a(2933),p=a(3810),h=a(1540),x=a(2881);/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let m=(0,x.Z)("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]),u=(0,x.Z)("ChevronUp",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);var y=a(732);function v(){let e=(0,i.useParams)(),t=(0,i.useRouter)();e?.id;let{user:a}=(0,y.a)(),[x,v]=(0,s.useState)(null),[f,g]=(0,s.useState)(!0),[k,b]=(0,s.useState)(null),[w,j]=(0,s.useState)(!1),[P,M]=(0,s.useState)(!1),[Z,C]=(0,s.useState)(!1);return f?(0,r.jsxs)("div",{className:"min-h-screen bg-[#030712] flex flex-col items-center justify-center text-white space-y-4",children:[r.jsx(n.Z,{className:"w-10 h-10 animate-spin text-indigo-500"}),r.jsx("p",{className:"text-sm text-slate-400",children:"Loading Portfolio..."})]}):k||!x?(0,r.jsxs)("div",{className:"min-h-screen bg-[#030712] flex flex-col items-center justify-center text-white space-y-4 text-center p-4",children:[r.jsx("h2",{className:"text-2xl font-bold",children:"Portfolio Not Found"}),r.jsx("p",{className:"text-sm text-slate-400",children:"The requested portfolio link might have expired or been removed."}),r.jsx("a",{href:"/",className:"btn-primary text-xs py-2 px-4",children:"Create Portfolio"})]}):(0,r.jsxs)("div",{className:"min-h-screen bg-[#030712] relative",children:[(0,r.jsxs)("div",{className:"fixed top-4 right-4 z-50 flex items-center gap-2 p-2 rounded-2xl transition-all duration-300 shadow-2xl",style:{background:"rgba(10,15,30,0.85)",backdropFilter:"blur(20px)",border:"1px solid rgba(255,255,255,0.1)"},children:[!Z&&(0,r.jsxs)(r.Fragment,{children:[P&&(0,r.jsxs)("button",{type:"button",onClick:()=>{x&&(o.V.saveDraftData(x.data),o.V.saveDraftTheme(x.theme),t.push(`/generate?step=3&theme=${x.theme}`))},className:"btn-primary text-xs py-1.5 px-3 bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-1.5",title:"Owner Control: Edit this portfolio",children:[r.jsx(d.Z,{className:"w-3.5 h-3.5"})," Edit Portfolio"]}),(0,r.jsxs)("button",{type:"button",onClick:()=>{navigator.clipboard.writeText(window.location.href),j(!0),setTimeout(()=>j(!1),2e3)},className:"btn-secondary text-xs py-1.5 px-3",title:"Share portfolio link",children:[w?r.jsx(c.Z,{className:"w-3.5 h-3.5 text-emerald-400"}):r.jsx(p.Z,{className:"w-3.5 h-3.5"}),w?"Copied":"Share"]}),(0,r.jsxs)("button",{type:"button",onClick:()=>{if(!x)return;let e=new Blob([`<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${x.data.name} — Recruiter Portfolio</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
</head>
<body class="bg-[#030712] text-slate-100 p-8">
  <div class="max-w-4xl mx-auto space-y-8">
    <h1 class="text-5xl font-extrabold text-white">${x.data.name}</h1>
    <p class="text-xl text-indigo-400 font-semibold">${x.data.title}</p>
    <p class="text-sm text-slate-300">${x.data.about}</p>
  </div>
</body>
</html>`],{type:"text/html"}),t=URL.createObjectURL(e),a=document.createElement("a");a.href=t,a.download=`${x.data.name.replace(/\s+/g,"_")}_Portfolio.html`,document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(t)},className:"btn-secondary text-xs py-1.5 px-3",title:"Download standalone HTML file",children:[r.jsx(h.Z,{className:"w-3.5 h-3.5"})," HTML"]})]}),r.jsx("button",{type:"button",onClick:()=>C(!Z),className:"p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors",title:Z?"Expand toolbar":"Minimize toolbar",children:Z?r.jsx(m,{className:"w-4 h-4"}):r.jsx(u,{className:"w-4 h-4"})})]}),r.jsx(l.X,{data:x.data,theme:x.theme})]})}},3402:(e,t,a)=>{"use strict";a.d(t,{V:()=>r});let r={getDraftData:()=>null,saveDraftData(e){},clearDraft(){},getDraftTheme:()=>"modern-glass",saveDraftTheme(e){},savePortfolioToHistory(e,t){},getSavedPortfolios:e=>[],deleteSavedPortfolio(e,t){}}},7546:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(2881).Z)("Briefcase",[["path",{d:"M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16",key:"jecpp"}],["rect",{width:"20",height:"14",x:"2",y:"6",rx:"2",key:"i6l2r4"}]])},2933:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(2881).Z)("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]])},4550:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(2881).Z)("CodeXml",[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]])},3810:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(2881).Z)("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]])},1208:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(2881).Z)("Cpu",[["rect",{width:"16",height:"16",x:"4",y:"4",rx:"2",key:"14l7u7"}],["rect",{width:"6",height:"6",x:"9",y:"9",rx:"1",key:"5aljv4"}],["path",{d:"M15 2v2",key:"13l42r"}],["path",{d:"M15 20v2",key:"15mkzm"}],["path",{d:"M2 15h2",key:"1gxd5l"}],["path",{d:"M2 9h2",key:"1bbxkp"}],["path",{d:"M20 15h2",key:"19e6y8"}],["path",{d:"M20 9h2",key:"19tzq7"}],["path",{d:"M9 2v2",key:"165o2o"}],["path",{d:"M9 20v2",key:"i2bqo8"}]])},1540:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(2881).Z)("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]])},7027:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(2881).Z)("ExternalLink",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]])},8375:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(2881).Z)("FolderGit2",[["path",{d:"M9 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v5",key:"1w6njk"}],["circle",{cx:"13",cy:"12",r:"2",key:"1j92g6"}],["path",{d:"M18 19c-2.8 0-5-2.2-5-5v8",key:"pkpw2h"}],["circle",{cx:"20",cy:"19",r:"2",key:"1obnsp"}]])},7506:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(2881).Z)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},2685:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(2881).Z)("PenLine",[["path",{d:"M12 20h9",key:"t2du7b"}],["path",{d:"M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z",key:"1ykcvy"}]])},4185:(e,t,a)=>{"use strict";a.r(t),a.d(t,{$$typeof:()=>o,__esModule:()=>i,default:()=>l});var r=a(8570);let s=(0,r.createProxy)(String.raw`C:\Users\dream\OneDrive\Desktop\PortfoliaAI\frontend\app\preview\[id]\page.tsx`),{__esModule:i,$$typeof:o}=s;s.default;let l=(0,r.createProxy)(String.raw`C:\Users\dream\OneDrive\Desktop\PortfoliaAI\frontend\app\preview\[id]\page.tsx#default`)}};var t=require("../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[406,451,290,773],()=>a(2137));module.exports=r})();